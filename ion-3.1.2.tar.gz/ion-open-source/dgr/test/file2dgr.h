/*
 *
 * 	file2dgr.h:	definitions used for the file2dgr DGR
 * 			benchmark system.
 *
 * 									*/

#include "dgr.h"

#define	TEST_PORT_NBR	2101
#define EOF_LINE_TEXT	"*** End of the file ***"
